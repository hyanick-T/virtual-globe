<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- CesiumJS loads at runtime from the official CDN (`src/lib/cesium-loader.ts`) inside `useEffect`, never as an npm import — it is browser-only and its workers/assets would bloat or break the Worker SSR bundle.
- Globe base imagery defaults to OpenStreetMap (no token); satellite imagery via Cesium ion is opt-in through a browser-side token (`src/lib/imagery.ts`), falling back to OpenStreetMap when missing or invalid. CZML scene files live in `public/SampleData/`.

- Trend statistics (OLS slope + two-sided t-test p-value) live in `src/lib/trend-stats.ts` and are computed server-side in `fetchClimate`, so the AI text and the Trend Report card always agree.
- Science overlays are NASA GIBS WMTS layers defined in `SCIENCE_LAYERS` (`src/lib/imagery.ts`), stacked over the base map for the selected date.
