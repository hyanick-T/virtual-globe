<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

People understand how Earth's climate is changing in the places they care about

## Metric

Trend reports shown to people who asked a climate question each week
