import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { runExplorer } from "./explorer.server";

const inputSchema = z.object({
  messages: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(4000) }))
    .min(1)
    .max(24),
  selectedDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  view: z.object({ lat: z.number(), lon: z.number(), heightKm: z.number() }).nullable(),
});

export type ExplorerInput = z.infer<typeof inputSchema>;

export const askExplorer = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data }) => runExplorer(data));
