// NASA data sources (no API key needed):
// - EONET v3: natural events (wildfires, storms, volcanoes, floods, ice...)
// - POWER: daily / monthly climate at any point on Earth since 1981
import type { ExplorerMarker, ExplorerSource, TrendReport } from "./explorer-types";
import { linearTrend } from "./trend-stats";
import { getNASAResourcesForTopic } from "./nasa-resources";
import { dailyClimateRange, isMissingClimateValue, monthlyClimateRange, todayIso } from "./nasa-dates";

const EONET_URL = "https://eonet.gsfc.nasa.gov/api/v3/events";
const POWER_URL = "https://power.larc.nasa.gov/api/temporal";

export const EONET_CATEGORIES = [
  "drought",
  "dustHaze",
  "earthquakes",
  "floods",
  "landslides",
  "manmade",
  "seaLakeIce",
  "severeStorms",
  "snow",
  "tempExtremes",
  "volcanoes",
  "waterColor",
  "wildfires",
] as const;

export const POWER_PARAMETERS = {
  T2M: "Average air temperature at 2 m",
  T2M_MAX: "Maximum air temperature at 2 m",
  T2M_MIN: "Minimum air temperature at 2 m",
  PRECTOTCORR: "Precipitation",
  RH2M: "Relative humidity at 2 m",
  WS2M: "Wind speed at 2 m",
  ALLSKY_SFC_SW_DWN: "Solar radiation reaching the surface",
} as const;

type PowerParam = keyof typeof POWER_PARAMETERS;

export type ToolResult = { data: unknown; markers?: ExplorerMarker[]; source?: ExplorerSource; reports?: TrendReport[] };

async function getJson(url: string, extraHeaders: Record<string, string> = {}): Promise<unknown> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(25_000),
    headers: { accept: "application/json", ...extraHeaders },
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`NASA service answered ${res.status}: ${text.slice(0, 300)}`);
  return JSON.parse(text);
}

const round = (n: number, d = 2) => Math.round(n * 10 ** d) / 10 ** d;

// ---------- NASA resource discovery ----------
const CMR_COLLECTIONS_URL = "https://cmr.earthdata.nasa.gov/search/collections.umm_json_v1_18_6";
const NASA_OPEN_DATA_SEARCH_URL = "https://data.nasa.gov/api/3/action/package_search";
const NASA_MEDIA_SEARCH_URL = "https://images-api.nasa.gov/search";

function cleanText(value: unknown, max = 420): string | null {
  if (typeof value !== "string") return null;
  const cleaned = value.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
  return cleaned ? cleaned.slice(0, max) : null;
}

export async function searchNasaDatasets(query: string, limit = 6): Promise<{ data: unknown; sources: ExplorerSource[] }> {
  const q = query.trim().slice(0, 120);
  if (q.length < 2) throw new Error("Please provide at least two characters to search NASA datasets.");
  const count = Math.max(1, Math.min(8, Math.trunc(limit) || 6));
  const cmrParams = new URLSearchParams({ keyword: q, page_size: String(count), sort_key: "score" });
  const openDataParams = new URLSearchParams({ q, rows: String(count) });
  const cmrUrl = `${CMR_COLLECTIONS_URL}?${cmrParams}`;
  const openDataUrl = `${NASA_OPEN_DATA_SEARCH_URL}?${openDataParams}`;

  const [cmrResult, openDataResult] = await Promise.allSettled([
    getJson(cmrUrl, { accept: "application/vnd.nasa.cmr.umm_results+json; version=1.18.6" }),
    getJson(openDataUrl),
  ]);

  const collections: Array<Record<string, unknown>> = [];
  if (cmrResult.status === "fulfilled") {
    const payload = cmrResult.value as { items?: Array<{ meta?: Record<string, unknown>; umm?: Record<string, unknown> }> };
    for (const item of payload.items ?? []) {
      const umm = item.umm ?? {};
      const conceptId = String(item.meta?.["concept-id"] ?? "");
      const title = cleanText(umm.EntryTitle, 220) ?? "Untitled NASA Earthdata collection";
      collections.push({
        source: "NASA Earthdata CMR",
        title,
        shortName: cleanText(umm.ShortName, 80),
        version: cleanText(umm.Version, 40),
        conceptId: conceptId || null,
        provider: cleanText(item.meta?.["provider-id"], 80),
        summary: cleanText(umm.Abstract, 520),
        doi: cleanText(umm.DOI, 120),
        url: `https://search.earthdata.nasa.gov/search?q=${encodeURIComponent(title)}`,
      });
    }
  }

  const openData: Array<Record<string, unknown>> = [];
  if (openDataResult.status === "fulfilled") {
    const payload = openDataResult.value as { success?: boolean; result?: { results?: Array<Record<string, unknown>> } };
    for (const item of payload.result?.results ?? []) {
      const name = cleanText(item.name, 160);
      const pageUrl = typeof item.url === "string" && item.url.startsWith("http")
        ? item.url
        : name
          ? `https://data.nasa.gov/dataset/${encodeURIComponent(name)}`
          : "https://data.nasa.gov/";
      openData.push({
        source: "NASA Open Data Portal",
        title: cleanText(item.title, 220) ?? name ?? "NASA dataset",
        description: cleanText(item.notes, 460),
        organization: cleanText(item.organization && typeof item.organization === "object" ? (item.organization as Record<string, unknown>).title : null, 120),
        resources: Array.isArray(item.resources) ? item.resources.length : null,
        url: pageUrl,
      });
    }
  }

  const sources: ExplorerSource[] = [];
  if (cmrResult.status === "fulfilled") sources.push({ label: "NASA Earthdata CMR search", url: cmrUrl });
  if (openDataResult.status === "fulfilled") sources.push({ label: "NASA Open Data catalog search", url: openDataUrl });

  return {
    data: {
      query: q,
      earthdataCollections: collections,
      openDataCatalog: openData,
      notes: [
        "NASA Open Data Portal entries are often metadata records; the actual dataset files may be hosted by a NASA archive.",
        "CMR results describe searchable Earth-observation collections. Check collection documentation, spatial/temporal coverage, units and quality flags before analysis.",
      ],
      availability: {
        earthdataCmr: cmrResult.status === "fulfilled" ? "available" : "unavailable",
        nasaOpenData: openDataResult.status === "fulfilled" ? "available" : "unavailable",
      },
    },
    sources,
  };
}

export async function searchNasaMedia(query: string, mediaType: "image" | "video" | "audio" = "image", limit = 5): Promise<{ data: unknown; sources: ExplorerSource[] }> {
  const q = query.trim().slice(0, 120);
  if (q.length < 2) throw new Error("Please provide at least two characters to search NASA media.");
  const params = new URLSearchParams({ q, media_type: mediaType, page_size: String(Math.max(1, Math.min(8, Math.trunc(limit) || 5))) });
  const url = `${NASA_MEDIA_SEARCH_URL}?${params}`;
  const json = (await getJson(url)) as {
    collection?: {
      metadata?: { total_hits?: number };
      items?: Array<{
        data?: Array<Record<string, unknown>>;
        links?: Array<{ href?: string; rel?: string; render?: string }>;
      }>;
    };
  };
  const items = (json.collection?.items ?? []).map((item) => {
    const meta = item.data?.[0] ?? {};
    const preview = item.links?.find((link) => link.rel === "preview")?.href ?? null;
    const nasaId = cleanText(meta.nasa_id, 80);
    return {
      title: cleanText(meta.title, 220),
      nasaId,
      mediaType: cleanText(meta.media_type, 20),
      dateCreated: cleanText(meta.date_created, 40),
      center: cleanText(meta.center, 40),
      description: cleanText(meta.description, 420),
      previewUrl: preview,
      url: nasaId ? `https://images.nasa.gov/details/${encodeURIComponent(nasaId)}` : "https://images.nasa.gov/",
    };
  });
  return {
    data: { query: q, mediaType, totalHits: json.collection?.metadata?.total_hits ?? items.length, items },
    sources: [{ label: "NASA Image and Video Library API", url }],
  };
}

export function getNasaResourceGuide(topic: string): { data: unknown; sources: ExplorerSource[] } {
  const resources = getNASAResourcesForTopic(topic);
  return {
    data: {
      topic: topic.trim() || "NASA and Space Apps resources",
      resources: resources.map(({ name, description, url, group }) => ({ name, description, url, group })),
      importantDistinction: "The NASA APIs portal is a directory of selected APIs, not a single universal API. NASA Open Data is a metadata catalog; NASA Earthdata and its archives host and provide access to Earth-observation datasets. NASA Science provides research and mission context.",
    },
    sources: resources.map((resource) => ({ label: resource.name, url: resource.url })),
  };
}


// ---------- EONET ----------
type EonetGeometry = {
  date: string;
  type: string;
  coordinates: unknown;
  magnitudeValue?: number | null;
  magnitudeUnit?: string | null;
};
type EonetEvent = {
  id: string;
  title: string;
  description?: string | null;
  link: string;
  closed: string | null;
  categories: { id: string; title: string }[];
  sources?: { id: string; url: string }[];
  geometry: EonetGeometry[];
};

function geometryCenter(g: EonetGeometry): [number, number] | null {
  if (g.type === "Point" && Array.isArray(g.coordinates)) {
    const c = g.coordinates as number[];
    const lon = c[0];
    const lat = c[1];
    return lat !== undefined && lon !== undefined && Number.isFinite(lat) && Number.isFinite(lon) ? [lat, lon] : null;
  }
  if (g.type === "Polygon" && Array.isArray(g.coordinates)) {
    const ring = (g.coordinates as number[][][])[0] ?? [];
    if (!ring.length) return null;
    const lon = ring.reduce((s, p) => s + (p[0] ?? 0), 0) / ring.length;
    const lat = ring.reduce((s, p) => s + (p[1] ?? 0), 0) / ring.length;
    return [lat, lon];
  }
  return null;
}

export async function fetchNaturalEvents(args: {
  category: string | null;
  start: string | null;
  end: string | null;
  status: "open" | "closed" | "all" | null;
  bbox: { west: number; south: number; east: number; north: number } | null;
  limit: number | null;
}): Promise<ToolResult> {
  const params = new URLSearchParams();
  const hasDates = !!(args.start || args.end);
  params.set("status", args.status ?? (hasDates ? "all" : "open"));
  if (args.start) params.set("start", args.start);
  if (args.start || args.end) params.set("end", args.end ?? todayIso());
  if (args.category && (EONET_CATEGORIES as readonly string[]).includes(args.category)) {
    params.set("category", args.category);
  }
  if (args.bbox) {
    const { west, north, east, south } = args.bbox;
    params.set("bbox", [west, north, east, south].join(","));
  }
  const limit = Math.min(Math.max(args.limit ?? 40, 1), 60);
  params.set("limit", String(limit));

  const url = `${EONET_URL}?${params}`;
  const json = (await getJson(url)) as { events?: EonetEvent[] };
  const events = json.events ?? [];

  const markers: ExplorerMarker[] = [];
  const list = events.map((e) => {
    const sorted = [...e.geometry].sort((a, b) => a.date.localeCompare(b.date));
    const latest = sorted[sorted.length - 1];
    const center = latest ? geometryCenter(latest) : null;
    const category = e.categories[0]?.title ?? "Event";
    const magnitude =
      latest?.magnitudeValue != null ? `${latest.magnitudeValue} ${latest.magnitudeUnit ?? ""}`.trim() : null;
    if (center) {
      markers.push({
        id: e.id,
        lat: round(center[0], 4),
        lon: round(center[1], 4),
        title: e.title,
        category,
        date: latest?.date.slice(0, 10) ?? null,
        detail: [magnitude && `Size: ${magnitude}`, e.closed ? `Closed ${e.closed.slice(0, 10)}` : "Still active"]
          .filter(Boolean)
          .join(" · "),
        url: e.sources?.[0]?.url ?? e.link,
      });
    }
    return {
      title: e.title,
      category,
      first_seen: sorted[0]?.date.slice(0, 10) ?? null,
      last_seen: latest?.date.slice(0, 10) ?? null,
      status: e.closed ? `closed ${e.closed.slice(0, 10)}` : "active",
      lat: center ? round(center[0], 3) : null,
      lon: center ? round(center[1], 3) : null,
      magnitude,
      observations: e.geometry.length,
    };
  });

  const byCategory: Record<string, number> = {};
  for (const e of list) byCategory[e.category] = (byCategory[e.category] ?? 0) + 1;

  return {
    data: {
      query: Object.fromEntries(params),
      returned: list.length,
      may_have_more: list.length >= limit,
      by_category: byCategory,
      events: list,
    },
    markers,
    source: { label: "NASA EONET", url },
  };
}

// ---------- POWER ----------
export async function fetchClimate(args: {
  lat: number;
  lon: number;
  resolution: "daily" | "monthly";
  start: string | null;
  end: string | null;
  parameters: string[] | null;
  label: string | null;
}): Promise<ToolResult> {
  const lat = Math.max(-90, Math.min(90, args.lat));
  const lon = Math.max(-180, Math.min(180, args.lon));
  const chosen = (args.parameters ?? []).filter((p): p is PowerParam => p in POWER_PARAMETERS);
  const parameters: PowerParam[] = chosen.length ? chosen : ["T2M", "T2M_MAX", "T2M_MIN", "PRECTOTCORR"];

  let range: { start: string; end: string };
  if (args.resolution === "monthly") {
    const y = (v: string | null) => (v ? Number(v.slice(0, 4)) : null);
    const r = monthlyClimateRange(y(args.start), y(args.end));
    range = { start: String(r.start), end: String(r.end) };
  } else {
    const r = dailyClimateRange(args.start, args.end);
    range = { start: r.start.replaceAll("-", ""), end: r.end.replaceAll("-", "") };
  }

  const qs = new URLSearchParams({
    parameters: parameters.join(","),
    community: "RE",
    latitude: String(round(lat, 4)),
    longitude: String(round(lon, 4)),
    start: range.start,
    end: range.end,
    format: "JSON",
  });
  const url = `${POWER_URL}/${args.resolution}/point?${qs}`;
  const json = (await getJson(url)) as {
    properties?: { parameter?: Record<string, Record<string, number>> };
    parameters?: Record<string, { units: string; longname: string }>;
  };

  const out: Record<string, unknown> = {};
  const reports: TrendReport[] = [];
  let lastAvailable: string | null = null;
  for (const p of parameters) {
    const raw = json.properties?.parameter?.[p] ?? {};
    // Monthly responses include a "13" pseudo-month holding the annual mean.
    const points = Object.entries(raw)
      .filter(([k, v]) => !(args.resolution === "monthly" && k.endsWith("13")) && !isMissingClimateValue(v))
      .map(([k, v]) => ({ t: formatPowerKey(k), v }));
    if (!points.length) {
      out[p] = { name: POWER_PARAMETERS[p], note: "No data available yet for this period" };
      continue;
    }
    const values = points.map((x) => x.v);
    const max = points.reduce((a, b) => (b.v > a.v ? b : a));
    const min = points.reduce((a, b) => (b.v < a.v ? b : a));
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const n = values.length;
    // Fit against actual calendar time, not the index of the surviving records.
    // This avoids overstating rates when missing dates have been removed.
    const timeYears = points.map((point) => {
      const timestamp = Date.parse(args.resolution === "monthly" ? `${point.t}-01T00:00:00Z` : `${point.t}T00:00:00Z`);
      return timestamp / (365.2425 * 24 * 60 * 60 * 1000);
    });
    const fit = linearTrend(values, timeYears);
    const elapsedYears = timeYears[timeYears.length - 1]! - timeYears[0]!;
    const totalChange = fit.slope * elapsedYears;
    const startFit = fit.intercept;
    const last = points[points.length - 1]!.t;
    if (!lastAvailable || last > lastAvailable) lastAvailable = last;
    reports.push({
      id: `${p}-${round(lat, 3)}-${round(lon, 3)}-${range.start}-${range.end}`,
      title: `${POWER_PARAMETERS[p]}${args.label ? ` · ${args.label}` : ""}`,
      variable: p,
      units: json.parameters?.[p]?.units ?? null,
      resolution: args.resolution,
      points: points.map((x, i) => ({ t: x.t, v: round(x.v), fit: round(fit.intercept + fit.slope * (timeYears[i]! - timeYears[0]!), 3) })),
      totalChange: round(totalChange, 3),
      totalChangePct: Math.abs(startFit) > 0.01 ? round((totalChange / Math.abs(startFit)) * 100, 1) : null,
      ratePerYear: round(fit.slope, 4),
      pValue: fit.pValue === null ? null : round(fit.pValue, 4),
      n,
    });
    const step = Math.max(1, Math.ceil(points.length / 62));
    out[p] = {
      name: POWER_PARAMETERS[p],
      units: json.parameters?.[p]?.units ?? null,
      first: points[0]!.t,
      last,
      count: n,
      mean: round(mean),
      min: { value: round(min.v), at: min.t },
      max: { value: round(max.v), at: max.t },
      trend_per_year: round(fit.slope, 4),
      trend_p_value_ols_nominal: fit.pValue === null ? null : round(fit.pValue, 4),
      trend_significant_ols_nominal: fit.pValue !== null && fit.pValue < 0.05,
      trend_test_note: "Conventional OLS slope t-test; screening result only. It does not adjust for seasonality or serial autocorrelation.",
      change_first_to_last: round(values[n - 1]! - values[0]!),
      series: points.filter((_x, i) => i % step === 0 || i === n - 1).map((x) => [x.t, round(x.v)]),
    };
  }

  const marker: ExplorerMarker = {
    id: `power-${round(lat, 3)}-${round(lon, 3)}`,
    lat,
    lon,
    title: args.label ?? `Climate point ${round(lat, 2)}, ${round(lon, 2)}`,
    category: "Climate",
    date: lastAvailable,
    detail: `NASA POWER ${args.resolution} data ${formatPowerKey(range.start)} → ${formatPowerKey(range.end)}`,
    url: null,
  };

  return {
    data: {
      location: { lat, lon, label: args.label },
      resolution: args.resolution,
      requested: { start: formatPowerKey(range.start), end: formatPowerKey(range.end) },
      latest_available: lastAvailable,
      note: "NASA POWER usually lags 2–5 days behind today; missing observations were removed. Trend rates use actual calendar elapsed time. The reported OLS p-value is nominal and does not adjust for seasonality or serial autocorrelation.",
      parameters: out,
    },
    markers: [marker],
    reports,
    source: { label: "NASA POWER", url },
  };
}

function formatPowerKey(k: string): string {
  if (/^\d{8}$/.test(k)) return `${k.slice(0, 4)}-${k.slice(4, 6)}-${k.slice(6)}`;
  if (/^\d{6}$/.test(k)) return `${k.slice(0, 4)}-${k.slice(4)}`;
  return k;
}
