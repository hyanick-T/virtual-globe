// Shared, browser-safe types for the AI Explorer and the globe.
export type ExplorerMarker = {
  id: string;
  lat: number;
  lon: number;
  title: string;
  category: string;
  date: string | null;
  detail: string | null;
  url: string | null;
};

export type GlobeAction =
  | { type: "fly_to"; lat: number; lon: number; heightKm: number; label: string | null }
  | { type: "set_date"; date: string }
  | { type: "show_markers"; markers: ExplorerMarker[] }
  | { type: "clear_markers" };

export type ChatTurn = { role: "user" | "assistant"; content: string };

export type ExplorerSource = { label: string; url: string };

export type TrendReport = {
  id: string;
  title: string; // e.g. "Temperature at 2 m · Kigali"
  variable: string;
  units: string | null;
  resolution: "daily" | "monthly";
  points: { t: string; v: number; fit: number }[];
  totalChange: number; // fitted change across the period
  totalChangePct: number | null;
  ratePerYear: number;
  pValue: number | null;
  n: number;
};

export type ExplorerReply =
  | { ok: true; reply: string; actions: GlobeAction[]; sources: ExplorerSource[]; reports: TrendReport[] }
  | { ok: false; error: string };

export type GlobeView = { lat: number; lon: number; heightKm: number };
