// CesiumJS is loaded from its official CDN at runtime (browser only).
// This keeps the heavy library and its workers/assets out of the server bundle.
export const CESIUM_VERSION = "1.147";
export const CESIUM_BASE = `https://cesium.com/downloads/cesiumjs/releases/${CESIUM_VERSION}/Build/Cesium`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type CesiumNS = any;

let loading: Promise<CesiumNS> | null = null;

export function loadCesium(): Promise<CesiumNS> {
  const w = window as unknown as { Cesium?: CesiumNS };
  if (w.Cesium) return Promise.resolve(w.Cesium);
  if (loading) return loading;
  loading = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = `${CESIUM_BASE}/Cesium.js`;
    script.async = true;
    script.onload = () => resolve(w.Cesium);
    script.onerror = () => {
      loading = null;
      reject(new Error("Could not load the 3D globe library."));
    };
    document.head.appendChild(script);
  });
  return loading;
}
