// Date rules that keep NASA data as current as possible without asking for
// days that do not exist yet. All dates are UTC, formatted YYYY-MM-DD.
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const DAY_MS = 86_400_000;

// MODIS Terra true-colour imagery starts here.
export const EARLIEST_IMAGERY_DATE = "2000-02-24";
// NASA POWER daily/monthly records start in 1981.
export const EARLIEST_CLIMATE_YEAR = 1981;
// Longest daily climate window fetched in one go.
export const MAX_DAILY_SPAN_DAYS = 366;

export function toIsoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function isIsoDate(value: string | null | undefined): value is string {
  return !!value && ISO.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}

export function addDays(date: string, days: number): string {
  return toIsoDate(new Date(Date.parse(`${date}T00:00:00Z`) + days * DAY_MS));
}

export function todayIso(now: Date = new Date()): string {
  return toIsoDate(now);
}

// Today's global mosaic is still being assembled, so yesterday is the newest full day.
export function latestImageryDate(now: Date = new Date()): string {
  return addDays(todayIso(now), -1);
}

export function clampImageryDate(date: string | null | undefined, now: Date = new Date()): string {
  const latest = latestImageryDate(now);
  if (!isIsoDate(date)) return latest;
  if (date > latest) return latest;
  if (date < EARLIEST_IMAGERY_DATE) return EARLIEST_IMAGERY_DATE;
  return date;
}

// Daily climate window: defaults to the last 30 days, never ends after today,
// never spans more than MAX_DAILY_SPAN_DAYS (keeps the end, moves the start).
export function dailyClimateRange(
  start: string | null | undefined,
  end: string | null | undefined,
  now: Date = new Date(),
): { start: string; end: string } {
  const today = todayIso(now);
  let e = isIsoDate(end) && end <= today ? end : today;
  let s = isIsoDate(start) ? start : addDays(e, -29);
  if (s > e) [s, e] = [e, s];
  const earliest = `${EARLIEST_CLIMATE_YEAR}-01-01`;
  if (s < earliest) s = earliest;
  if (addDays(s, MAX_DAILY_SPAN_DAYS - 1) < e) s = addDays(e, -(MAX_DAILY_SPAN_DAYS - 1));
  return { start: s, end: e };
}

export function monthlyClimateRange(
  startYear: number | null | undefined,
  endYear: number | null | undefined,
  now: Date = new Date(),
): { start: number; end: number } {
  const thisYear = now.getUTCFullYear();
  const clampYear = (y: number) => Math.min(thisYear, Math.max(EARLIEST_CLIMATE_YEAR, Math.trunc(y)));
  let e = clampYear(endYear ?? thisYear);
  let s = clampYear(startYear ?? e);
  if (s > e) [s, e] = [e, s];
  return { start: s, end: e };
}

// NASA POWER marks missing values (e.g. the last few days) with -999.
export function isMissingClimateValue(v: unknown): boolean {
  return typeof v !== "number" || !Number.isFinite(v) || v <= -999;
}
