// Base-map choice for the globe. Both need no account or token.
// "nasa" = NASA GIBS daily true-colour satellite mosaic for the selected date.
export type ImageryChoice = "nasa" | "map";

export const OSM_URL = "https://tile.openstreetmap.org/";

export function nasaDailyImageryUrl(date: string): string {
  return `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/${date}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg`;
}

export const NASA_LABELS_URL =
  "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/Reference_Labels_15m/default/default/GoogleMapsCompatible_Level13/{z}/{y}/{x}.png";

// NASA GIBS science overlays drawn on top of the base map for the selected date.
export type ScienceLayerId = "temperature" | "precipitation" | "fires" | "aerosol";
export type ScienceLayer = { id: ScienceLayerId; label: string; hint: string; gibsId: string; maxLevel: number };

export const SCIENCE_LAYERS: ScienceLayer[] = [
  { id: "temperature", label: "Surface Temperature", hint: "MODIS land surface temp, daytime", gibsId: "MODIS_Terra_Land_Surface_Temp_Day", maxLevel: 7 },
  { id: "precipitation", label: "Precipitation Rate", hint: "GPM IMERG rainfall", gibsId: "IMERG_Precipitation_Rate", maxLevel: 6 },
  { id: "fires", label: "Active Wildfires", hint: "NASA FIRMS · VIIRS hotspots", gibsId: "VIIRS_SNPP_Thermal_Anomalies_375m_All", maxLevel: 8 },
  { id: "aerosol", label: "Aerosol Optical Depth", hint: "MODIS haze, smoke & dust", gibsId: "MODIS_Combined_Value_Added_AOD", maxLevel: 6 },
];

export function scienceLayerUrl(layer: ScienceLayer, date: string): string {
  return `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${layer.gibsId}/default/${date}/GoogleMapsCompatible_Level${layer.maxLevel}/{z}/{y}/{x}.png`;
}
