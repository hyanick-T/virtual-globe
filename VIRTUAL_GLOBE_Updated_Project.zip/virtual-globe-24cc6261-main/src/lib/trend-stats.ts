// Ordinary least-squares trend with an optional numeric time axis.
// If xValues are supplied, slope is expressed per one unit of that axis.
// The p-value is a conventional two-sided OLS t-test and assumes independent,
// approximately well-behaved residuals; it does not correct seasonality or autocorrelation.
export type TrendStats = {
  slope: number;
  intercept: number;
  pValue: number | null;
  n: number;
};

export function linearTrend(values: number[], xValues?: number[]): TrendStats {
  const n = values.length;
  if (xValues && xValues.length !== n) {
    throw new Error("xValues must have the same length as values.");
  }
  if (values.some((value) => !Number.isFinite(value)) || (xValues && xValues.some((value) => !Number.isFinite(value)))) {
    throw new Error("Trend inputs must contain only finite numbers.");
  }
  if (n < 2) return { slope: 0, intercept: values[0] ?? 0, pValue: null, n };

  // Center the time axis at its first observation to keep date-sized values stable.
  const x = xValues ? xValues.map((value) => value - xValues[0]!) : values.map((_value, index) => index);
  const xMean = x.reduce((sum, value) => sum + value, 0) / n;
  const yMean = values.reduce((sum, value) => sum + value, 0) / n;
  let sxx = 0;
  let sxy = 0;
  values.forEach((y, index) => {
    sxx += (x[index]! - xMean) ** 2;
    sxy += (x[index]! - xMean) * (y - yMean);
  });
  if (sxx === 0) return { slope: 0, intercept: yMean, pValue: null, n };

  const slope = sxy / sxx;
  const intercept = yMean - slope * xMean;
  if (n < 3) return { slope, intercept, pValue: null, n };

  const sse = values.reduce((sum, y, index) => sum + (y - (intercept + slope * x[index]!)) ** 2, 0);
  const se = Math.sqrt(sse / (n - 2) / sxx);
  if (se === 0) return { slope, intercept, pValue: slope === 0 ? 1 : 0, n };
  const t = slope / se;
  return { slope, intercept, pValue: twoSidedP(t, n - 2), n };
}

// p = I_{df/(df+t^2)}(df/2, 1/2)
export function twoSidedP(t: number, df: number): number {
  return Math.min(1, Math.max(0, regIncBeta(df / (df + t * t), df / 2, 0.5)));
}

function logGamma(x: number): number {
  const c = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
  let y = x;
  const tmp = x + 5.5 - (x + 0.5) * Math.log(x + 5.5);
  let ser = 1.000000000190015;
  for (const ci of c) ser += ci / ++y;
  return -tmp + Math.log((2.5066282746310005 * ser) / x);
}

function regIncBeta(x: number, a: number, b: number): number {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const bt = Math.exp(logGamma(a + b) - logGamma(a) - logGamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  if (x < (a + 1) / (a + b + 2)) return (bt * betaCf(x, a, b)) / a;
  return 1 - (bt * betaCf(1 - x, b, a)) / b;
}

function betaCf(x: number, a: number, b: number): number {
  const FPMIN = 1e-300;
  let c = 1;
  let d = 1 - ((a + b) * x) / (a + 1);
  if (Math.abs(d) < FPMIN) d = FPMIN;
  d = 1 / d;
  let h = d;
  for (let m = 1; m <= 200; m++) {
    const m2 = 2 * m;
    let aa = (m * (b - m) * x) / ((a + m2 - 1) * (a + m2));
    d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d; h *= d * c;
    aa = (-(a + m) * (a + b + m) * x) / ((a + m2) * (a + m2 + 1));
    d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 3e-12) break;
  }
  return h;
}
