// AI Explorer: a tool-calling loop on the Lovable AI Gateway that reads live
// NASA data and returns a plain-text explanation plus globe actions.
import { GatewayError, generateResponse, type ResponsesInputItem } from "@lovable.dev/ai-gateway";
import type { ExplorerInput } from "./explorer.functions";
import type { ExplorerMarker, ExplorerReply, ExplorerSource, GlobeAction, TrendReport } from "./explorer-types";
import {
  EONET_CATEGORIES,
  POWER_PARAMETERS,
  fetchClimate,
  fetchNaturalEvents,
  getNasaResourceGuide,
  searchNasaDatasets,
  searchNasaMedia,
} from "./nasa.server";
import { clampImageryDate, latestImageryDate, todayIso } from "./nasa-dates";

const MODEL = "openai/gpt-6-astra" as const;
const MAX_ROUNDS = 6;

type Payload = Parameters<typeof generateResponse<typeof MODEL>>[0];
type Tools = NonNullable<Payload["tools"]>;

const nullable = (schema: Record<string, unknown>) => ({ ...schema, type: [schema["type"] as string, "null"] });

const TOOLS: Tools = [
  {
    type: "function",
    name: "get_natural_events",
    description:
      "NASA EONET natural events (wildfires, severe storms, volcanoes, floods, sea/lake ice, dust, drought...). " +
      "With no dates it returns events active right now. Results are also drawn as markers on the globe.",
    strict: true,
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["category", "start", "end", "status", "bbox", "limit"],
      properties: {
        category: nullable({ type: "string", enum: [...EONET_CATEGORIES, null] }),
        start: nullable({ type: "string", description: "YYYY-MM-DD" }),
        end: nullable({ type: "string", description: "YYYY-MM-DD" }),
        status: nullable({ type: "string", enum: ["open", "closed", "all", null] }),
        bbox: {
          type: ["object", "null"],
          additionalProperties: false,
          required: ["west", "south", "east", "north"],
          properties: {
            west: { type: "number" },
            south: { type: "number" },
            east: { type: "number" },
            north: { type: "number" },
          },
        },
        limit: nullable({ type: "integer", description: "1-60, default 40" }),
      },
    },
  },
  {
    type: "function",
    name: "get_climate_data",
    description:
      "NASA POWER climate data for one point (since 1981). Use resolution 'daily' for days/weeks/a month " +
      "(max 366 days) and 'monthly' for whole years or multi-year trends. Missing recent days are dropped. " +
      "Also places a marker on the globe.",
    strict: true,
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["lat", "lon", "label", "resolution", "start", "end", "parameters"],
      properties: {
        lat: { type: "number" },
        lon: { type: "number" },
        label: nullable({ type: "string", description: "Place name" }),
        resolution: { type: "string", enum: ["daily", "monthly"] },
        start: nullable({ type: "string", description: "daily: YYYY-MM-DD, monthly: YYYY" }),
        end: nullable({ type: "string", description: "daily: YYYY-MM-DD, monthly: YYYY" }),
        parameters: {
          type: ["array", "null"],
          items: { type: "string", enum: Object.keys(POWER_PARAMETERS) },
          description: Object.entries(POWER_PARAMETERS)
            .map(([k, v]) => `${k}: ${v}`)
            .join("; "),
        },
      },
    },
  },
  {
    type: "function",
    name: "get_nasa_resource_guide",
    description:
      "Return official NASA and NASA Space Apps reference links, including the Kigali local event, Space Apps challenge site, NASA Open Data, Earthdata, NASA Science, NASA APIs, GIBS, CMR, AppEEARS, EONET, POWER and NASA media documentation. Use this when users ask about the challenge, official resources, data access guidance or which NASA source to use.",
    strict: true,
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["topic"],
      properties: { topic: { type: "string", description: "Topic or NASA resource the user wants to understand; may be empty for all official resources." } },
    },
  },
  {
    type: "function",
    name: "search_nasa_datasets",
    description:
      "Search live NASA Earthdata CMR collection metadata and the NASA Open Data Portal catalog. Use for finding official datasets about a scientific variable, location, mission or sensor. Results are metadata and discovery links, not necessarily downloadable measurements. Check product coverage and quality documentation before analysis.",
    strict: true,
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["query", "limit"],
      properties: {
        query: { type: "string", description: "Short dataset search phrase such as MODIS land surface temperature, rainfall Africa, vegetation NDVI, or soil moisture." },
        limit: { type: "integer", description: "Number of results, 1 to 8." },
      },
    },
  },
  {
    type: "function",
    name: "search_nasa_media",
    description:
      "Search NASA's official Image and Video Library API for NASA-published images or videos related to Earth science, satellites, missions or a place. Returns source metadata, dates and preview links. Media is explanatory/visual context, not scientific measurement data.",
    strict: true,
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["query", "media_type", "limit"],
      properties: {
        query: { type: "string" },
        media_type: { type: "string", enum: ["image", "video", "audio"] },
        limit: { type: "integer", description: "Number of results, 1 to 8." },
      },
    },
  },
  {
    type: "function",
    name: "fly_to",
    description: "Move the globe camera over a place.",
    strict: true,
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["lat", "lon", "height_km", "label"],
      properties: {
        lat: { type: "number" },
        lon: { type: "number" },
        height_km: { type: "number", description: "Camera altitude, e.g. 300 for a city, 3000 for a country, 15000 for a continent" },
        label: nullable({ type: "string" }),
      },
    },
  },
  {
    type: "function",
    name: "set_date",
    description: "Change the globe's satellite imagery to a specific day (YYYY-MM-DD).",
    strict: true,
    parameters: {
      type: "object",
      additionalProperties: false,
      required: ["date"],
      properties: { date: { type: "string" } },
    },
  },
  {
    type: "function",
    name: "clear_markers",
    description: "Remove markers the explorer placed earlier.",
    strict: true,
    parameters: { type: "object", additionalProperties: false, required: [], properties: {} },
  },
];

function instructions(input: ExplorerInput): string {
  const now = new Date();
  const view = input.view
    ? `The camera is over lat ${input.view.lat.toFixed(2)}, lon ${input.view.lon.toFixed(2)} at ${Math.round(input.view.heightKm)} km.`
    : "";
  return [
    "You are the AI Explorer inside VIRTUAL GLOBE, an interactive 3D Earth System Trend Detective.",
    "You have live tools for NASA EONET natural events, NASA POWER climate observations, NASA Earthdata CMR and NASA Open Data dataset discovery, NASA Image and Video Library media search, and an official NASA/Space Apps resource directory.",
    `Today is ${todayIso(now)} (UTC). The globe shows NASA satellite imagery for ${input.selectedDate}; the newest full day of imagery is ${latestImageryDate(now)}. ${view}`,
    "Tool selection rules:",
    "- For current or historical natural events (fires, storms, volcanoes, floods, drought, etc.), call get_natural_events before giving facts.",
    "- For numeric climate observations or a time-series/trend at a location, call get_climate_data. It uses NASA POWER; it is distinct from MODIS land-surface temperature.",
    "- For questions about datasets, missions, variables, sensors, spatial coverage or data availability, call search_nasa_datasets. This searches both NASA Earthdata CMR and NASA Open Data metadata catalogs.",
    "- For NASA photos or videos, call search_nasa_media. Explain that media is visual context, not a scientific measurement.",
    "- For official challenge details, the Kigali local event, NASA Open Data, Earthdata, NASA Science, or the NASA APIs portal, call get_nasa_resource_guide and provide the relevant official links.",
    "- NASA Open Data entries are often metadata and may link to files hosted in a NASA archive. CMR is Earth-observation collection metadata search. NASA Science is mission/research context. api.nasa.gov is a directory of selected APIs, not a single universal Earth-data endpoint.",
    "- NASA GIBS layers shown on the globe are browse visualizations; do not calculate scientific trends from tile colours. Use source measurements (such as NASA POWER or an appropriately retrieved Earthdata product) for numeric analysis.",
    "Scientific rules:",
    "- Always fetch real NASA data with the relevant tools before stating events, measurements or trends. Never invent values; if data are missing, say so.",
    "- A trend is a direction over time, not one unusual observation. Distinguish trend, anomaly, seasonality, weather and climate.",
    "- Do not say a non-significant p-value proves there is no trend. Explain that it means insufficient evidence to reject the no-trend hypothesis under the test assumptions.",
    "- Statistical significance is not the same as practical importance or causation. Mention the method's limitations when relevant.",
    "- Land-surface temperature is not the same as 2-m air temperature. State which variable and units were measured.",
    "Interaction rules:",
    "- 'This place' / 'here' means the current camera position. Call fly_to for the location you investigate.",
    "- Call set_date when the user asks about a specific imagery date or period, using a date within that period.",
    "- No date given means current active EONET events or the last 30 days of climate data, using the most recent available observations.",
    "- A month means its first to last day for daily climate. A whole year means monthly climate for that year.",
    "- Explain the exact date range, source, units and NASA POWER's usual several-day reporting lag when relevant.",
    "Reply rules:",
    "- Answer in the user's language. Use plain language, short paragraphs and bullets. Keep it concise unless the user asks for detail.",
    "- Include the official source name and rely on the source links returned by tools. Do not claim to have read a portal page's full contents when the resource guide only supplied its link.",
  ].join("\n");
}

type FunctionCall = { type: "function_call"; name: string; arguments: string; call_id: string };

export async function runExplorer(input: ExplorerInput): Promise<ExplorerReply> {
  const actions: GlobeAction[] = [];
  const sources: ExplorerSource[] = [];
  const reports = new Map<string, TrendReport>();
  const markers = new Map<string, ExplorerMarker>();

  const conversation: ResponsesInputItem[] = input.messages.map((m) =>
    m.role === "user"
      ? { role: "user", content: m.content }
      : { role: "assistant", content: [{ type: "output_text", text: m.content }] },
  );

  const runTool = async (call: FunctionCall): Promise<unknown> => {
    const args = JSON.parse(call.arguments || "{}");
    switch (call.name) {
      case "get_natural_events":
      case "get_climate_data": {
        const result = call.name === "get_natural_events" ? await fetchNaturalEvents(args) : await fetchClimate(args);
        for (const m of result.markers ?? []) markers.set(m.id, m);
        if (result.source) sources.push(result.source);
        for (const r of result.reports ?? []) reports.set(r.id, r);
        return result.data;
      }
      case "get_nasa_resource_guide": {
        const result = getNasaResourceGuide(args.topic ?? "");
        sources.push(...result.sources);
        return result.data;
      }
      case "search_nasa_datasets": {
        const result = await searchNasaDatasets(args.query, args.limit);
        sources.push(...result.sources);
        return result.data;
      }
      case "search_nasa_media": {
        const result = await searchNasaMedia(args.query, args.media_type, args.limit);
        sources.push(...result.sources);
        return result.data;
      }
      case "fly_to":
        actions.push({ type: "fly_to", lat: args.lat, lon: args.lon, heightKm: args.height_km, label: args.label });
        return { ok: true };
      case "set_date": {
        const date = clampImageryDate(args.date);
        actions.push({ type: "set_date", date });
        return { ok: true, date, note: date !== args.date ? "Adjusted to the nearest day with imagery" : undefined };
      }
      case "clear_markers":
        markers.clear();
        actions.push({ type: "clear_markers" });
        return { ok: true };
      default:
        return { error: `Unknown tool ${call.name}` };
    }
  };

  try {
    for (let round = 0; round < MAX_ROUNDS; round++) {
      const res = await generateResponse({
        model: MODEL,
        instructions: instructions(input),
        input: conversation,
        tools: TOOLS,
        reasoning: { effort: "low" },
        include: ["reasoning.encrypted_content"],
      });

      const calls = res.output.filter((o): o is typeof o & FunctionCall => o.type === "function_call");
      if (!calls.length) {
        const reply = res.output
          .flatMap((o) => (o.type === "message" ? o.content : []))
          .map((c) => (c.type === "output_text" ? c.text : ""))
          .join("")
          .trim();
        if (markers.size) actions.push({ type: "show_markers", markers: [...markers.values()] });
        return { ok: true, reply: reply || "I couldn't put an answer together. Try asking another way.", actions, sources, reports: [...reports.values()] };
      }

      // Stateless tool loop: hand the model's own output items back with each tool result.
      conversation.push(...(res.output as unknown as ResponsesInputItem[]));
      for (const call of calls) {
        let output: unknown;
        try {
          output = await runTool(call);
        } catch (e) {
          output = { error: e instanceof Error ? e.message : "Tool failed" };
        }
        conversation.push({ type: "function_call_output", call_id: call.call_id, output: JSON.stringify(output) });
      }
    }
    if (markers.size) actions.push({ type: "show_markers", markers: [...markers.values()] });
    return { ok: true, reply: "I gathered the data but ran out of steps. Ask me to summarise it.", actions, sources, reports: [...reports.values()] };
  } catch (e) {
    if (e instanceof GatewayError) {
      console.error("AI Explorer gateway error", e.code, e.httpStatus, e.ids);
      if (e.httpStatus === 429) return { ok: false, error: "The AI is busy right now. Please wait a moment and try again." };
      if (e.httpStatus === 402) return { ok: false, error: "AI credits have run out for this workspace. Add credits to keep exploring." };
      return { ok: false, error: "The AI Explorer couldn't answer just now. Please try again." };
    }
    console.error("AI Explorer failed", e);
    return { ok: false, error: "Something went wrong while fetching NASA data. Please try again." };
  }
}
