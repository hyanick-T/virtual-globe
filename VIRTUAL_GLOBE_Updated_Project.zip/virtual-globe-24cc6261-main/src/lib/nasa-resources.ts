/** Curated NASA and Space Apps reference directory used by the UI and AI Explorer. */
export type NASAResource = {
  id: string;
  name: string;
  description: string;
  url: string;
  group: "challenge" | "data" | "api" | "science";
  keywords: string[];
};

export const NASA_RESOURCES: NASAResource[] = [
  {
    id: "kigali-event",
    name: "NASA Space Apps Challenge — Kigali, Rwanda",
    description: "Local event information, registration context and Kigali community details.",
    url: "https://www.spaceappschallenge.org/2026/local-events/kigali/",
    group: "challenge",
    keywords: ["kigali", "rwanda", "local event", "registration", "space apps"],
  },
  {
    id: "space-apps",
    name: "NASA Space Apps Challenge — Official Website",
    description: "Official challenge information, participation guidance, challenges and announcements.",
    url: "https://www.spaceappschallenge.org/",
    group: "challenge",
    keywords: ["challenge", "space apps", "competition", "submission", "judging"],
  },
  {
    id: "open-data",
    name: "NASA Open Data Portal",
    description: "NASA public dataset catalog. Many entries are metadata records that link to the archive where the data files are hosted.",
    url: "https://data.nasa.gov/",
    group: "data",
    keywords: ["open data", "dataset catalog", "metadata", "data.nasa.gov"],
  },
  {
    id: "earthdata",
    name: "NASA Earthdata",
    description: "NASA Earth-observation data discovery, archives, tools, learning resources and access guidance.",
    url: "https://www.earthdata.nasa.gov/",
    group: "data",
    keywords: ["earth observation", "satellite", "earthdata", "remote sensing", "archives"],
  },
  {
    id: "science",
    name: "NASA Science",
    description: "NASA science topics, missions, research context, Earth science and educational explanations.",
    url: "https://science.nasa.gov/",
    group: "science",
    keywords: ["science", "earth science", "missions", "research", "education"],
  },
  {
    id: "api-portal",
    name: "NASA APIs Portal",
    description: "Directory of selected developer-friendly NASA APIs. It is a catalog of APIs, not a single universal Earth-data API.",
    url: "https://api.nasa.gov/",
    group: "api",
    keywords: ["api", "developer", "api key", "web services"],
  },
  {
    id: "gibs",
    name: "NASA Global Imagery Browse Services (GIBS)",
    description: "Public map imagery services (WMTS, WMS and tile services) for browsing Earth-observation visualizations. Use analysis-grade source products for numerical trend calculations.",
    url: "https://nasa-gibs.github.io/gibs-api-docs/",
    group: "api",
    keywords: ["gibs", "imagery", "map layers", "wmts", "wms", "satellite imagery", "modis", "temperature", "land surface temperature", "precipitation", "fire", "vegetation"],
  },
  {
    id: "cmr",
    name: "NASA Common Metadata Repository (CMR) Search API",
    description: "Searches NASA Earth-observation collection and granule metadata across data providers.",
    url: "https://cmr.earthdata.nasa.gov/search/site/docs/search/api.html",
    group: "api",
    keywords: ["cmr", "collection", "granule", "metadata search", "earthdata search"],
  },
  {
    id: "appeears",
    name: "NASA AppEEARS",
    description: "Extracts and subsets supported NASA land and atmosphere products by area, point, time and selected layers. Requires an Earthdata account for authenticated tasks.",
    url: "https://appeears.earthdatacloud.nasa.gov/",
    group: "api",
    keywords: ["appeears", "subset", "extract", "point", "area", "modis"],
  },
  {
    id: "eonet",
    name: "NASA EONET API v3",
    description: "Natural-event metadata including wildfires, severe storms, volcanoes, floods and other tracked events.",
    url: "https://eonet.gsfc.nasa.gov/docs/v3",
    group: "api",
    keywords: ["eonet", "wildfire", "fire", "storm", "volcano", "flood", "natural event"],
  },
  {
    id: "power",
    name: "NASA POWER API",
    description: "Daily and monthly meteorological and solar parameters for selected locations, with temporal coverage dependent on parameter and product.",
    url: "https://power.larc.nasa.gov/docs/services/api/",
    group: "api",
    keywords: ["power", "climate", "rainfall", "precipitation", "temperature", "wind", "humidity"],
  },
  {
    id: "images",
    name: "NASA Image and Video Library API",
    description: "Searches NASA-published images and videos and returns media metadata and preview links.",
    url: "https://images.nasa.gov/docs/images.nasa.gov_api_docs.pdf",
    group: "api",
    keywords: ["images", "video", "media", "photography", "visual resources"],
  },
];

export function getNASAResourcesForTopic(topic = ""): NASAResource[] {
  const query = topic.trim().toLowerCase();
  if (!query) return NASA_RESOURCES;
  const words = query.split(/\s+/).filter((word) => word.length > 2);
  const ranked = NASA_RESOURCES.map((resource) => {
    const haystack = `${resource.name} ${resource.description} ${resource.keywords.join(" ")}`.toLowerCase();
    const score = words.reduce((sum, word) => sum + (haystack.includes(word) ? 1 : 0), 0);
    return { resource, score };
  }).filter((entry) => entry.score > 0);
  return (ranked.length ? ranked.sort((a, b) => b.score - a.score) : NASA_RESOURCES).map((entry) => entry.resource).slice(0, 8);
}
