import { createFileRoute } from "@tanstack/react-router";
import { GlobeViewer } from "@/components/GlobeViewer";
import { CESIUM_BASE } from "@/lib/cesium-loader";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Virtual Globe — Explore Earth & Its Changes" },
      {
        name: "description",
        content: "Search any place, view NASA daily satellite imagery and ask an AI explorer about natural events and climate trends.",
      },
      { property: "og:title", content: "Virtual Globe — Explore Earth & Its Changes" },
      {
        property: "og:description",
        content: "Search any place, view NASA daily satellite imagery and ask an AI explorer about natural events and climate trends.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "stylesheet", href: `${CESIUM_BASE}/Widgets/widgets.css` }],
  }),
  component: Index,
});

function Index() {
  return <GlobeViewer />;
}
