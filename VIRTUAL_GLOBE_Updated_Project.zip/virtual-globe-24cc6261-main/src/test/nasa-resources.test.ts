import { describe, expect, it } from "vitest";
import { getNASAResourcesForTopic, NASA_RESOURCES } from "@/lib/nasa-resources";

describe("NASA resource directory", () => {
  it("includes the official NASA and Kigali Space Apps resources", () => {
    const urls = NASA_RESOURCES.map((resource) => resource.url);
    expect(urls).toContain("https://www.spaceappschallenge.org/2026/local-events/kigali/");
    expect(urls).toContain("https://www.spaceappschallenge.org/");
    expect(urls).toContain("https://data.nasa.gov/");
    expect(urls).toContain("https://www.earthdata.nasa.gov/");
    expect(urls).toContain("https://science.nasa.gov/");
    expect(urls).toContain("https://api.nasa.gov/");
  });

  it("prioritizes related resources for a topic", () => {
    const resources = getNASAResourcesForTopic("MODIS land surface temperature");
    expect(resources.some((resource) => resource.id === "appeears")).toBe(true);
    expect(resources.some((resource) => resource.id === "gibs")).toBe(true);
  });
});
