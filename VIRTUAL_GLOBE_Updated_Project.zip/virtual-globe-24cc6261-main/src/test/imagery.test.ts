import { describe, expect, it } from "vitest";
import {
  clampImageryDate,
  dailyClimateRange,
  isMissingClimateValue,
  latestImageryDate,
  monthlyClimateRange,
} from "@/lib/nasa-dates";
import { nasaDailyImageryUrl } from "@/lib/imagery";

const NOW = new Date("2026-11-12T13:00:00Z");

describe("NASA date rules keep data current", () => {
  it("newest satellite imagery is yesterday", () => {
    expect(latestImageryDate(NOW)).toBe("2026-11-11");
  });

  it("a future or invalid date falls back to the newest imagery", () => {
    expect(clampImageryDate("2027-01-01", NOW)).toBe("2026-11-11");
    expect(clampImageryDate("not-a-date", NOW)).toBe("2026-11-11");
  });

  it("dates before MODIS imagery begins snap to its first day", () => {
    expect(clampImageryDate("1995-06-01", NOW)).toBe("2000-02-24");
  });

  it("climate data defaults to the last 30 days ending today", () => {
    expect(dailyClimateRange(null, null, NOW)).toEqual({ start: "2026-10-14", end: "2026-11-12" });
  });

  it("climate data never ends after today and is capped at 366 days", () => {
    expect(dailyClimateRange("2020-01-01", "2030-01-01", NOW)).toEqual({ start: "2025-11-12", end: "2026-11-12" });
  });

  it("monthly climate years stay between 1981 and this year", () => {
    expect(monthlyClimateRange(1970, 2030, NOW)).toEqual({ start: 1981, end: 2026 });
  });

  it("-999 values from NASA POWER count as missing", () => {
    expect(isMissingClimateValue(-999)).toBe(true);
    expect(isMissingClimateValue(20.5)).toBe(false);
  });

  it("imagery URL carries the chosen date", () => {
    expect(nasaDailyImageryUrl("2026-11-11")).toContain("/default/2026-11-11/");
  });
});
