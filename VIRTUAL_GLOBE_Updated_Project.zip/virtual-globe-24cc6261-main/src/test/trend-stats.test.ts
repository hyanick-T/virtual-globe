import { describe, expect, it } from "vitest";
import { linearTrend, twoSidedP } from "@/lib/trend-stats";

describe("trend stats", () => {
  it("t=2.228 with 10 df gives p≈0.05", () => {
    expect(twoSidedP(2.228, 10)).toBeCloseTo(0.05, 3);
  });
  it("a clean rising series is significant", () => {
    const r = linearTrend([1, 2.1, 2.9, 4.2, 5, 5.9, 7.1, 8]);
    expect(r.slope).toBeCloseTo(1, 1);
    expect(r.pValue!).toBeLessThan(0.05);
  });
  it("noise with no trend is not significant", () => {
    expect(linearTrend([5, 3, 6, 4, 5, 3, 6, 4]).pValue!).toBeGreaterThanOrEqual(0.05);
  });
  it("fits against actual elapsed time when observations are irregular", () => {
    const result = linearTrend([10, 12, 16], [2000, 2001, 2003]);
    expect(result.slope).toBeCloseTo(2, 8);
    expect(result.intercept).toBeCloseTo(10, 8);
  });
  it("rejects mismatched or non-finite time axes", () => {
    expect(() => linearTrend([1, 2], [0])).toThrow("same length");
    expect(() => linearTrend([1, Number.NaN])).toThrow("finite numbers");
  });
});
