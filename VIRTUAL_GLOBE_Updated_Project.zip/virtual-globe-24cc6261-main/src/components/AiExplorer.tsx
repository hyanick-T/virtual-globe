import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { askExplorer } from "@/lib/explorer.functions";
import type { ChatTurn, ExplorerSource, GlobeAction, GlobeView, TrendReport } from "@/lib/explorer-types";
import { cn } from "@/lib/utils";

type Message = ChatTurn & { sources?: ExplorerSource[]; error?: boolean };

const SUGGESTIONS = [
  "Find NASA MODIS land-surface temperature datasets for Rwanda",
  "What are the official NASA Space Apps Kigali 2026 resources?",
  "Search NASA images and videos of Earth-observation satellites",
  "Show recent NASA natural events around the world",
  "Compare NASA POWER rainfall in Kigali over the last five years",
];

export function AiExplorer({
  selectedDate,
  getView,
  onActions,
  onReports,
  disabled,
}: {
  onReports: (reports: TrendReport[]) => void;
  selectedDate: string;
  getView: () => GlobeView | null;
  onActions: (actions: GlobeAction[]) => void;
  disabled: boolean;
}) {
  const ask = useServerFn(askExplorer);
  const [open, setOpen] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  const send = async (text: string) => {
    const content = text.trim();
    if (!content || busy) return;
    const next: Message[] = [...messages, { role: "user", content }];
    setMessages(next);
    setDraft("");
    setBusy(true);
    try {
      const history = next
        .filter((m) => !m.error)
        .slice(-12)
        .map(({ role, content }) => ({ role, content }));
      const res = await ask({ data: { messages: history, selectedDate, view: getView() } });
      if (res.ok) {
        onActions(res.actions);
        if (res.reports.length) onReports(res.reports);
        setMessages((m) => [...m, { role: "assistant", content: res.reply, sources: dedupe(res.sources) }]);
      } else {
        setMessages((m) => [...m, { role: "assistant", content: res.error, error: true }]);
      }
    } catch {
      setMessages((m) => [
        ...m,
        { role: "assistant", content: "I couldn't reach the explorer. Check your connection and try again.", error: true },
      ]);
    } finally {
      setBusy(false);
    }
  };

  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="explorer-fab">
        <span className="status-dot status-dot-live" />
        AI Explorer
      </button>
    );
  }

  return (
    <section aria-label="AI Explorer" className="glass-panel explorer-panel">
      <header className="flex items-start justify-between gap-3 border-b border-border px-4 py-3">
        <div>
          <p className="font-mono text-[0.65rem] uppercase tracking-[0.3em] text-primary">NASA data · official knowledge sources</p>
          <h2 className="font-display text-lg font-semibold leading-tight text-foreground">AI Explorer</h2>
          <p className="mt-0.5 text-[0.65rem] text-muted-foreground">Events · climate · dataset search · NASA media</p>
        </div>
        <button
          type="button"
          onClick={() => setOpen(false)}
          aria-label="Hide AI Explorer"
          className="rounded-md px-2 py-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          ✕
        </button>
      </header>

      <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-3">
        {messages.length === 0 && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Ask about Earth systems, climate, NASA datasets, missions, images or the Space Apps challenge. I can search official NASA catalogues, retrieve climate and event data, explain trends and move the globe for you.
            </p>
            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <button key={s} type="button" disabled={disabled} onClick={() => send(s)} className="explorer-chip">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={cn("explorer-msg", m.role === "user" ? "explorer-msg-user" : "explorer-msg-ai", m.error && "explorer-msg-error")}>
            <p className="whitespace-pre-wrap">{m.content}</p>
            {m.sources && m.sources.length > 0 && (
              <p className="mt-2 flex flex-wrap gap-x-3 gap-y-1 font-mono text-[0.65rem] text-muted-foreground">
                {m.sources.map((s) => (
                  <a key={s.url} href={s.url} target="_blank" rel="noreferrer" className="text-primary underline-offset-2 hover:underline">
                    {s.label} ↗
                  </a>
                ))}
              </p>
            )}
          </div>
        ))}

        {busy && (
          <div className="explorer-msg explorer-msg-ai flex items-center gap-2 text-muted-foreground">
            <span className="status-dot status-dot-live" />
            Consulting NASA data and official sources…
          </div>
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          void send(draft);
        }}
        className="flex gap-2 border-t border-border p-3"
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Ask about NASA data, trends or Earth science…"
          aria-label="Ask the AI Explorer"
          maxLength={1000}
          disabled={disabled}
          className="min-w-0 flex-1 rounded-md border border-border bg-input px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
        />
        <button
          type="submit"
          disabled={disabled || busy || !draft.trim()}
          className="rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          Ask
        </button>
      </form>
    </section>
  );
}

function dedupe(sources: ExplorerSource[]): ExplorerSource[] {
  const seen = new Set<string>();
  return sources.filter((s) => (seen.has(s.label) ? false : (seen.add(s.label), true)));
}
