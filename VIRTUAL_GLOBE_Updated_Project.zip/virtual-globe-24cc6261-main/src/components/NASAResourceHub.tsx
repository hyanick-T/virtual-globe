import { useState } from "react";
import { ExternalLink, BookOpen, Database, Satellite, Trophy } from "lucide-react";
import { NASA_RESOURCES, type NASAResource } from "@/lib/nasa-resources";

const GROUPS = [
  { id: "challenge", label: "Challenge & Kigali", icon: Trophy },
  { id: "data", label: "NASA data portals", icon: Database },
  { id: "api", label: "APIs & data services", icon: Satellite },
  { id: "science", label: "Science & research", icon: BookOpen },
] as const;

export function NASAResourceHub() {
  const [open, setOpen] = useState(false);
  const [activeGroup, setActiveGroup] = useState<NASAResource["group"] | "all">("all");
  const resources = NASA_RESOURCES.filter((resource) => activeGroup === "all" || resource.group === activeGroup);

  return (
    <section className="mt-5 border-t border-border pt-4" aria-label="NASA resource hub">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        className="flex w-full items-center justify-between text-left"
      >
        <span>
          <span className="block font-mono text-[0.65rem] uppercase tracking-[0.3em] text-primary">Official knowledge sources</span>
          <span className="mt-1 block font-display text-sm font-semibold text-foreground">NASA Resource Hub</span>
        </span>
        <span className="rounded-md border border-border px-2 py-1 text-xs text-muted-foreground">{open ? "Hide −" : "Explore +"}</span>
      </button>
      {open && (
        <div className="mt-3 space-y-3">
          <p className="text-xs leading-relaxed text-muted-foreground">
            Open official NASA and Space Apps sources. AI Explorer can also search NASA dataset metadata and media from these services.
          </p>
          <div className="flex flex-wrap gap-1.5">
            <button type="button" onClick={() => setActiveGroup("all")} className={`explorer-chip ${activeGroup === "all" ? "border-primary text-primary" : ""}`}>
              All sources
            </button>
            {GROUPS.map((group) => {
              const Icon = group.icon;
              return (
                <button key={group.id} type="button" onClick={() => setActiveGroup(group.id)} className={`explorer-chip inline-flex items-center gap-1 ${activeGroup === group.id ? "border-primary text-primary" : ""}`}>
                  <Icon className="h-3 w-3" aria-hidden="true" /> {group.label}
                </button>
              );
            })}
          </div>
          <div className="space-y-2">
            {resources.map((resource) => (
              <a
                key={resource.id}
                href={resource.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group block rounded-lg border border-border/80 bg-card/70 p-2.5 transition-colors hover:border-primary/60 hover:bg-accent/60"
              >
                <span className="flex items-start justify-between gap-2">
                  <span className="text-xs font-semibold leading-snug text-foreground">{resource.name}</span>
                  <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground group-hover:text-primary" aria-hidden="true" />
                </span>
                <span className="mt-1 block text-[0.7rem] leading-relaxed text-muted-foreground">{resource.description}</span>
              </a>
            ))}
          </div>
          <p className="font-mono text-[0.6rem] uppercase tracking-wider text-muted-foreground">
            Sources are official reference links; individual data services may have separate access and usage terms.
          </p>
        </div>
      )}
    </section>
  );
}
