import { useState } from "react";
import { CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip as ChartTooltip, XAxis, YAxis, Bar } from "recharts";
import type { TrendReport } from "@/lib/explorer-types";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const fmt = (v: number, d = 2) => `${v > 0 ? "+" : ""}${Number(v.toFixed(d))}`;
const isRain = (r: TrendReport) => r.variable.startsWith("PREC");

export function TrendReportCard({ reports, onClose }: { reports: TrendReport[]; onClose: () => void }) {
  const [idx, setIdx] = useState(0);
  const r = reports[Math.min(idx, reports.length - 1)];
  if (!r) return null;
  const unit = r.units ? ` ${r.units}` : "";
  const significant = r.pValue !== null && r.pValue < 0.05;
  const perDecade = r.resolution === "monthly" && r.n >= 36;
  // Short daily windows: per-year extrapolation would mislead, so show per day.
  const perDay = r.resolution === "daily" && r.n <= 90;
  const rate = perDecade ? r.ratePerYear * 10 : perDay ? r.ratePerYear / 365.25 : r.ratePerYear;
  const rateUnit = perDecade ? "decade" : perDay ? "day" : "year";

  return (
    <section aria-label="Scientific Trend Report" className="glass-panel trend-report p-4">
      <header className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-mono text-[0.65rem] uppercase tracking-[0.3em] text-primary">Scientific Trend Report</p>
          <h2 className="truncate font-display text-base font-semibold text-foreground">{r.title}</h2>
          <p className="font-mono text-[0.65rem] text-muted-foreground">
            NASA POWER · {r.resolution} · {r.points[0]?.t} → {r.points[r.points.length - 1]?.t} · n={r.n}
          </p>
        </div>
        <button type="button" onClick={onClose} aria-label="Close trend report" className="px-2 text-sm text-muted-foreground hover:text-foreground">
          ✕
        </button>
      </header>

      {reports.length > 1 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {reports.map((x, i) => (
            <button key={x.id} type="button" onClick={() => setIdx(i)} className={cn("explorer-chip", i === idx && "border-primary text-primary")}>
              {x.variable}
            </button>
          ))}
        </div>
      )}

      <div className="mt-3 grid grid-cols-3 gap-2">
        <div className="metric-badge">
          <p className="text-[0.65rem] uppercase tracking-wider text-muted-foreground">Total change</p>
          <p className="font-mono text-sm font-semibold text-foreground">
            {isRain(r) && r.totalChangePct !== null ? `${fmt(r.totalChangePct, 1)}%` : `${fmt(r.totalChange)}${unit}`}
          </p>
        </div>
        <div className="metric-badge">
          <p className="text-[0.65rem] uppercase tracking-wider text-muted-foreground">Rate of change</p>
          <p className="font-mono text-sm font-semibold text-foreground">
            {fmt(rate, 3)}
            {unit} / {rateUnit}
          </p>
        </div>
        <div className="metric-badge">
          <p className="text-[0.65rem] uppercase tracking-wider text-muted-foreground">Significance</p>
          <TooltipProvider delayDuration={100}>
            <Tooltip>
              <TooltipTrigger asChild>
                <span
                  tabIndex={0}
                  className={cn(
                    "mt-0.5 inline-block cursor-help rounded-full px-2 py-0.5 text-[0.65rem] font-semibold",
                    r.pValue === null
                      ? "bg-muted text-muted-foreground"
                      : significant
                        ? "bg-success/20 text-success"
                        : "bg-warning/20 text-warning",
                  )}
                >
                  {r.pValue === null
                    ? "Not enough data"
                    : significant
                      ? "Nominal OLS p < 0.05"
                      : "Nominal OLS p ≥ 0.05"}
                </span>
              </TooltipTrigger>
              <TooltipContent className="max-w-64 text-xs">
                This is a conventional two-sided OLS slope test. Its p-value is not the probability that the trend is true.
                This screening test does not adjust for seasonal structure or serial autocorrelation, so it should not be
                treated as final climate-trend significance without further checks.
                {r.pValue !== null && ` Here p = ${r.pValue < 0.0001 ? "< 0.0001" : r.pValue.toFixed(4)}.`}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <p className="mt-2 rounded-md border border-warning/30 bg-warning/5 px-2.5 py-2 text-[0.68rem] leading-relaxed text-muted-foreground">
        Screening estimate: the linear fit uses actual elapsed calendar time. The nominal OLS p-value does not account
        for seasonality or serial autocorrelation; interpret it cautiously.
      </p>

      <div className="mt-3 h-52 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={r.points} margin={{ top: 5, right: 8, bottom: 0, left: -12 }}>
            <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
            <XAxis dataKey="t" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} minTickGap={24} />
            <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} domain={["auto", "auto"]} />
            <ChartTooltip
              contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}
              labelStyle={{ color: "var(--foreground)" }}
            />
            {isRain(r) ? (
              <Bar dataKey="v" name={`Value${unit}`} fill="var(--chart-2)" />
            ) : (
              <Line dataKey="v" name={`Value${unit}`} stroke="var(--primary)" dot={false} strokeWidth={2} />
            )}
            <Line dataKey="fit" name="Linear trend" stroke="var(--foreground)" strokeDasharray="6 4" dot={false} strokeWidth={1.5} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
