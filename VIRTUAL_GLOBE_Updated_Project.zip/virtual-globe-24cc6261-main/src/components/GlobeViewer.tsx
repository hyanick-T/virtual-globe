import { useCallback, useEffect, useRef, useState } from "react";
import { AiExplorer } from "@/components/AiExplorer";
import { NASAResourceHub } from "@/components/NASAResourceHub";
import { PlaceSearch, type Place } from "@/components/PlaceSearch";
import { TrendReportCard } from "@/components/TrendReportCard";
import { loadCesium } from "@/lib/cesium-loader";
import type { ExplorerMarker, GlobeAction, GlobeView, TrendReport } from "@/lib/explorer-types";
import { NASA_LABELS_URL, OSM_URL, SCIENCE_LAYERS, nasaDailyImageryUrl, scienceLayerUrl, type ImageryChoice, type ScienceLayerId } from "@/lib/imagery";
import { EARLIEST_IMAGERY_DATE, clampImageryDate, latestImageryDate } from "@/lib/nasa-dates";
import { cn } from "@/lib/utils";

export type GlobeMode = "satellites" | "vehicle";

const MODES: { id: GlobeMode; label: string; hint: string }[] = [
  { id: "satellites", label: "Satellites", hint: "Orbits around Earth" },
  { id: "vehicle", label: "Vehicle", hint: "Drive across the Mojave" },
];

// 3D building styling options (Cesium 3D Tiles Styling language).
export type BuildingStyle = "material" | "residential" | "offices" | "apartments" | "distance";

const BUILDING_STYLES: { id: BuildingStyle; label: string }[] = [
  { id: "material", label: "By material" },
  { id: "residential", label: "Homes" },
  { id: "offices", label: "Offices only" },
  { id: "apartments", label: "Apartments only" },
  { id: "distance", label: "By distance" },
];

const IMAGERY: { id: ImageryChoice; label: string; hint: string }[] = [
  { id: "nasa", label: "NASA daily", hint: "Satellite photo of the day" },
  { id: "map", label: "Street map", hint: "OpenStreetMap" },
];

// Marker colours are drawn inside the 3D canvas, which cannot read CSS theme tokens.
const CATEGORY_COLORS: Record<string, string> = {
  Wildfires: "#ff6b35",
  "Severe Storms": "#4cc9f0",
  Volcanoes: "#e63946",
  Floods: "#3a86ff",
  "Sea and Lake Ice": "#caf0f8",
  Climate: "#ffd166",
};

export function GlobeViewer() {
  const containerRef = useRef<HTMLDivElement>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const viewerRef = useRef<any>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cesiumRef = useRef<any>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<GlobeMode | null>(null);
  const [demosOpen, setDemosOpen] = useState(false);
  const [buildingsOn, setBuildingsOn] = useState(false);
  const [buildingStyle, setBuildingStyle] = useState<BuildingStyle>("material");
  const [buildingsMsg, setBuildingsMsg] = useState<string | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const tilesetRef = useRef<any>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const clickHandlerRef = useRef<any>(null);
  const [layers, setLayers] = useState<ScienceLayerId[]>([]);
  const [reports, setReports] = useState<TrendReport[] | null>(null);
  const [imagery, setImagery] = useState<ImageryChoice>("nasa");
  const [date, setDate] = useState("");
  const [maxDate, setMaxDate] = useState("");

  // Dates depend on "now", so compute them after hydration.
  useEffect(() => {
    const latest = latestImageryDate();
    setMaxDate(latest);
    setDate(latest);
  }, []);

  // Create the viewer once.
  useEffect(() => {
    let cancelled = false;
    loadCesium()
      .then((Cesium) => {
        if (cancelled || !containerRef.current) return;
        cesiumRef.current = Cesium;
        const viewer = new Cesium.Viewer(containerRef.current, {
          shouldAnimate: true,
          baseLayer: new Cesium.ImageryLayer(new Cesium.OpenStreetMapImageryProvider({ url: OSM_URL })),
          baseLayerPicker: false,
          geocoder: false,
          sceneModePicker: true,
          navigationHelpButton: false,
          fullscreenButton: false,
        });
        viewerRef.current = viewer;
        setReady(true);
      })
      .catch((e: Error) => !cancelled && setError(e.message));

    return () => {
      cancelled = true;
      if (viewerRef.current && !viewerRef.current.isDestroyed()) viewerRef.current.destroy();
      viewerRef.current = null;
    };
  }, []);

  // Base imagery: NASA daily mosaic for the chosen date, or the street map.
  useEffect(() => {
    const viewer = viewerRef.current;
    const Cesium = cesiumRef.current;
    if (!ready || !viewer || !Cesium) return;
    viewer.imageryLayers.removeAll();
    if (imagery === "nasa" && date) {
      viewer.imageryLayers.addImageryProvider(
        new Cesium.UrlTemplateImageryProvider({
          url: nasaDailyImageryUrl(date),
          maximumLevel: 9,
          credit: new Cesium.Credit("NASA GIBS / MODIS Terra"),
        }),
      );
      viewer.imageryLayers.addImageryProvider(
        new Cesium.UrlTemplateImageryProvider({ url: NASA_LABELS_URL, maximumLevel: 13 }),
      );
    } else {
      viewer.imageryLayers.addImageryProvider(new Cesium.OpenStreetMapImageryProvider({ url: OSM_URL }));
    }
    for (const id of layers) {
      const def = SCIENCE_LAYERS.find((l) => l.id === id);
      if (!def || !date) continue;
      const layer = viewer.imageryLayers.addImageryProvider(
        new Cesium.UrlTemplateImageryProvider({
          url: scienceLayerUrl(def, date),
          maximumLevel: def.maxLevel,
          credit: new Cesium.Credit(`NASA GIBS / ${def.label}`),
        }),
      );
      layer.alpha = def.id === "fires" ? 1 : 0.6;
    }
  }, [imagery, date, ready, layers]);

  // Load the chosen scene (Sandcastle.reset + button handler).
  useEffect(() => {
    const viewer = viewerRef.current;
    const Cesium = cesiumRef.current;
    if (!ready || !viewer || !Cesium) return;

    viewer.dataSources.removeAll();

    if (mode === null) return;
    if (mode === "satellites") {
      viewer.dataSources.add(Cesium.CzmlDataSource.load("/SampleData/simple.czml"));
      viewer.camera.flyHome(0);
    } else {
      viewer.dataSources.add(Cesium.CzmlDataSource.load("/SampleData/Vehicle.czml"));
      viewer.scene.camera.setView({
        destination: Cesium.Cartesian3.fromDegrees(-116.52, 35.02, 95000),
        orientation: { heading: 6 },
      });
    }
  }, [mode, ready]);

  // 3D Buildings demo: OSM buildings tileset + world terrain, styled per buildingStyle.
  useEffect(() => {
    const viewer = viewerRef.current;
    const Cesium = cesiumRef.current;
    if (!ready || !viewer || !Cesium) return;
    let cancelled = false;

    const removeBuildings = () => {
      if (clickHandlerRef.current) {
        clickHandlerRef.current.destroy();
        clickHandlerRef.current = null;
      }
      if (tilesetRef.current) {
        viewer.scene.primitives.remove(tilesetRef.current);
        tilesetRef.current = null;
      }
    };

    if (!buildingsOn) {
      removeBuildings();
      setBuildingsMsg(null);
      return;
    }

    (async () => {
      try {
        if (!tilesetRef.current) {
          viewer.scene.globe.terrainProvider = await Cesium.createWorldTerrainAsync();
          const tileset = await Cesium.createOsmBuildingsAsync();
          if (cancelled) return;
          viewer.scene.primitives.add(tileset);
          tilesetRef.current = tileset;
        }
        if (cancelled) return;
        setBuildingsMsg(null);
        viewer.scene.camera.setView({
          destination: Cesium.Cartesian3.fromDegrees(-122.3472, 47.598, 370),
          orientation: { heading: Cesium.Math.toRadians(10), pitch: Cesium.Math.toRadians(-10) },
        });
      } catch {
        if (!cancelled) {
          setBuildingsMsg("3D buildings need a Cesium ion token — showing the globe without them.");
          setBuildingsOn(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [buildingsOn, ready]);

  // Apply the chosen building style (and the click-to-measure-distance handler).
  useEffect(() => {
    const viewer = viewerRef.current;
    const Cesium = cesiumRef.current;
    const tileset = tilesetRef.current;
    if (!ready || !viewer || !Cesium || !buildingsOn || !tileset) return;

    if (clickHandlerRef.current) {
      clickHandlerRef.current.destroy();
      clickHandlerRef.current = null;
    }

    if (buildingStyle === "material") {
      tileset.style = new Cesium.Cesium3DTileStyle({
        defines: { material: "${feature['building:material']}" },
        color: {
          conditions: [
            ["${material} === null", "color('white')"],
            ["${material} === 'glass'", "color('skyblue', 0.5)"],
            ["${material} === 'concrete'", "color('grey')"],
            ["${material} === 'brick'", "color('indianred')"],
            ["${material} === 'stone'", "color('lightslategrey')"],
            ["${material} === 'metal'", "color('lightgrey')"],
            ["${material} === 'steel'", "color('lightsteelblue')"],
            ["true", "color('white')"],
          ],
        },
      });
    } else if (buildingStyle === "residential") {
      tileset.style = new Cesium.Cesium3DTileStyle({
        color: {
          conditions: [
            ["${feature['building']} === 'apartments' || ${feature['building']} === 'residential'", "color('cyan', 0.9)"],
            ["true", "color('white')"],
          ],
        },
      });
    } else if (buildingStyle === "offices" || buildingStyle === "apartments") {
      tileset.style = new Cesium.Cesium3DTileStyle({
        show: `\${feature['building']} === '${buildingStyle === "offices" ? "office" : "apartments"}'`,
      });
    } else {
      // Color by distance from a clicked building (default: the Space Needle).
      const colorByDistance = (lat: number, lon: number) => {
        tileset.style = new Cesium.Cesium3DTileStyle({
          defines: {
            distance: `distance(vec2(\${feature['cesium#longitude']}, \${feature['cesium#latitude']}), vec2(${lon}, ${lat}))`,
          },
          color: {
            conditions: [
              ["${distance} > 0.014", "color('blue')"],
              ["${distance} > 0.010", "color('green')"],
              ["${distance} > 0.006", "color('yellow')"],
              ["${distance} > 0.0001", "color('red')"],
              ["true", "color('white')"],
            ],
          },
        });
      };
      colorByDistance(47.62051, -122.34931);
      const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
      handler.setInputAction((movement: { position: unknown }) => {
        viewer.selectedEntity = undefined;
        const picked = viewer.scene.pick(movement.position);
        if (picked && typeof picked.getProperty === "function") {
          const lat = picked.getProperty("cesium#latitude");
          const lon = picked.getProperty("cesium#longitude");
          if (typeof lat === "number" && typeof lon === "number") colorByDistance(lat, lon);
        }
      }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
      clickHandlerRef.current = handler;
    }

    return () => {
      if (clickHandlerRef.current) {
        clickHandlerRef.current.destroy();
        clickHandlerRef.current = null;
      }
    };
  }, [buildingStyle, buildingsOn, ready]);

  const getView = useCallback((): GlobeView | null => {
    const viewer = viewerRef.current;
    const Cesium = cesiumRef.current;
    if (!viewer || !Cesium) return null;
    const c = viewer.camera.positionCartographic;
    return {
      lat: Cesium.Math.toDegrees(c.latitude),
      lon: Cesium.Math.toDegrees(c.longitude),
      heightKm: c.height / 1000,
    };
  }, []);

  const showMarkers = useCallback((markers: ExplorerMarker[]) => {
    const viewer = viewerRef.current;
    const Cesium = cesiumRef.current;
    if (!viewer || !Cesium) return;
    viewer.entities.removeAll();
    for (const m of markers) {
      const color = Cesium.Color.fromCssColorString(CATEGORY_COLORS[m.category] ?? "#ffd166");
      viewer.entities.add({
        name: m.title,
        position: Cesium.Cartesian3.fromDegrees(m.lon, m.lat),
        point: { pixelSize: 10, color, outlineColor: Cesium.Color.BLACK, outlineWidth: 1.5 },
        label: {
          text: m.title.length > 32 ? `${m.title.slice(0, 30)}…` : m.title,
          font: "12px sans-serif",
          pixelOffset: new Cesium.Cartesian2(0, -16),
          fillColor: Cesium.Color.WHITE,
          showBackground: true,
          backgroundColor: Cesium.Color.BLACK.withAlpha(0.6),
          distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0, 6_000_000),
        },
        description: [
          `<p><b>${escapeHtml(m.category)}</b>${m.date ? ` · ${escapeHtml(m.date)}` : ""}</p>`,
          m.detail ? `<p>${escapeHtml(m.detail)}</p>` : "",
          m.url ? `<p><a href="${escapeHtml(m.url)}" target="_blank" rel="noreferrer">Source</a></p>` : "",
        ].join(""),
      });
    }
  }, []);

  const applyActions = useCallback(
    (actions: GlobeAction[]) => {
      const viewer = viewerRef.current;
      const Cesium = cesiumRef.current;
      if (!viewer || !Cesium) return;
      let flew = false;
      for (const a of actions) {
        if (a.type === "set_date") {
          setDate(clampImageryDate(a.date));
          setImagery("nasa");
        } else if (a.type === "clear_markers") {
          viewer.entities.removeAll();
        } else if (a.type === "show_markers") {
          showMarkers(a.markers);
        } else if (a.type === "fly_to") {
          flew = true;
          viewer.camera.flyTo({
            destination: Cesium.Cartesian3.fromDegrees(a.lon, a.lat, Math.max(5, a.heightKm) * 1000),
            duration: 2.5,
          });
        }
      }
      if (!flew && viewer.entities.values.length > 0) viewer.flyTo(viewer.entities, { duration: 2.5 });
    },
    [showMarkers],
  );

  const flyToPlace = useCallback((p: Place) => {
    const viewer = viewerRef.current;
    const Cesium = cesiumRef.current;
    if (!viewer || !Cesium) return;
    viewer.entities.removeAll();
    viewer.entities.add({
      name: p.name,
      position: Cesium.Cartesian3.fromDegrees(p.lon, p.lat),
      point: { pixelSize: 12, color: Cesium.Color.fromCssColorString("#ffd166"), outlineColor: Cesium.Color.BLACK, outlineWidth: 2 },
      description: `<p>${escapeHtml(p.name)}</p><p>${p.lat.toFixed(4)}°, ${p.lon.toFixed(4)}°</p>`,
    });
    if (p.bbox) {
      const [s, n, w, e] = p.bbox;
      viewer.camera.flyTo({ destination: Cesium.Rectangle.fromDegrees(w, s, e, n), duration: 2.5 });
    } else {
      viewer.camera.flyTo({ destination: Cesium.Cartesian3.fromDegrees(p.lon, p.lat, 50000), duration: 2.5 });
    }
  }, []);

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-background">
      <div ref={containerRef} className="globe-canvas absolute inset-0" />

      <aside className="glass-panel absolute left-3 top-3 z-10 max-h-[calc(100dvh-1.5rem)] w-[min(20rem,calc(100%-1.5rem))] overflow-y-auto p-4 sm:left-5 sm:top-5 sm:p-5">
        <p className="font-mono text-[0.65rem] uppercase tracking-[0.3em] text-primary">Explore Earth · Detect change</p>
        <h1 className="mt-1 font-display text-2xl font-semibold uppercase leading-tight tracking-wide text-foreground">Virtual Globe</h1>
        <p className="mt-1 text-sm text-muted-foreground">See Earth. Detect Change. Understand Impact.</p>

        <PlaceSearch onPick={flyToPlace} disabled={!ready} />

        <div className="mt-4 rounded-lg border border-primary/25 bg-primary/5 p-3">
          <p className="font-mono text-[0.6rem] uppercase tracking-[0.22em] text-primary">Mission · Earth System Trend Detective</p>
          <p className="mt-1 text-xs leading-relaxed text-foreground/90">
            Explore a place, select an Earth variable, compare observations over time and inspect the evidence behind a trend.
          </p>
        </div>
        <NASAResourceHub />

        <p className="mt-5 font-mono text-[0.65rem] uppercase tracking-[0.3em] text-primary">Scientific data layers</p>
        <div className="mt-2 space-y-1.5">
          {SCIENCE_LAYERS.map((l) => {
            const on = layers.includes(l.id);
            return (
              <button
                key={l.id}
                type="button"
                disabled={!ready}
                aria-pressed={on}
                onClick={() => {
                  setLayers((cur) => (on ? cur.filter((x) => x !== l.id) : [...cur, l.id]));
                  if (!on) setImagery("nasa");
                }}
                className={cn("mode-btn w-full", on && "mode-btn-active")}
              >
                <span className="block font-display text-sm font-semibold">{l.label}</span>
                <span className="mt-0.5 block text-[0.7rem] opacity-75">{l.hint}</span>
              </button>
            );
          })}
        </div>

        <p className="mt-5 font-mono text-[0.65rem] uppercase tracking-[0.3em] text-primary">Base map</p>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {IMAGERY.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setImagery(m.id)}
              disabled={!ready}
              aria-pressed={imagery === m.id}
              className={cn("mode-btn", imagery === m.id && "mode-btn-active")}
            >
              <span className="block font-display text-sm font-semibold">{m.label}</span>
              <span className="mt-0.5 block text-[0.7rem] opacity-75">{m.hint}</span>
            </button>
          ))}
        </div>

        <label htmlFor="globe-date" className="mt-3 block text-xs text-muted-foreground">
          Satellite photo date
        </label>
        <input
          id="globe-date"
          type="date"
          value={date}
          min={EARLIEST_IMAGERY_DATE}
          max={maxDate}
          onChange={(e) => {
            setDate(clampImageryDate(e.target.value));
            setImagery("nasa");
          }}
          className="mt-1 w-full rounded-md border border-border bg-input px-2.5 py-1.5 font-mono text-xs text-foreground focus:border-primary focus:outline-none"
        />

        <button
          type="button"
          onClick={() => setDemosOpen((o) => !o)}
          aria-expanded={demosOpen}
          className="mt-5 flex w-full items-center justify-between font-mono text-[0.65rem] uppercase tracking-[0.3em] text-muted-foreground hover:text-foreground"
        >
          Extra demos <span>{demosOpen ? "−" : "+"}</span>
        </button>
        {demosOpen && (
          <>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {MODES.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMode(mode === m.id ? null : m.id)}
                  disabled={!ready}
                  aria-pressed={mode === m.id}
                  className={cn("mode-btn", mode === m.id && "mode-btn-active")}
                >
                  <span className="block font-display text-sm font-semibold">{m.label}</span>
                  <span className="mt-0.5 block text-[0.7rem] opacity-75">{m.hint}</span>
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setBuildingsOn((o) => !o)}
              disabled={!ready}
              aria-pressed={buildingsOn}
              className={cn("mode-btn mt-2 w-full", buildingsOn && "mode-btn-active")}
            >
              <span className="block font-display text-sm font-semibold">3D Buildings</span>
              <span className="mt-0.5 block text-[0.7rem] opacity-75">Seattle city models, styled</span>
            </button>
            {buildingsOn && (
              <div className="mt-2 grid grid-cols-2 gap-2">
                {BUILDING_STYLES.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setBuildingStyle(s.id)}
                    aria-pressed={buildingStyle === s.id}
                    className={cn("mode-btn", buildingStyle === s.id && "mode-btn-active")}
                  >
                    <span className="block font-display text-xs font-semibold">{s.label}</span>
                  </button>
                ))}
                {buildingStyle === "distance" && (
                  <p className="col-span-2 text-[0.7rem] text-muted-foreground">Click any building to recolor by distance from it.</p>
                )}
              </div>
            )}
            {buildingsMsg && <p className="mt-2 text-[0.7rem] text-muted-foreground">{buildingsMsg}</p>}
          </>
        )}

        <p className="mt-4 flex items-center gap-2 font-mono text-[0.7rem] text-muted-foreground">
          <span className={cn("status-dot", ready && "status-dot-live", error && "status-dot-error")} />
          {error ? error : ready ? "Live · use the timeline below to scrub" : "Loading globe…"}
        </p>
      </aside>

      <AiExplorer selectedDate={date || "2000-02-24"} getView={getView} onActions={applyActions} onReports={setReports} disabled={!ready} />
      {reports && <TrendReportCard key={reports[0]?.id} reports={reports} onClose={() => setReports(null)} />}
    </div>
  );
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);
}
