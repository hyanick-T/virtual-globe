import { useState } from "react";

export type Place = { name: string; lat: number; lon: number; bbox?: [number, number, number, number] | undefined };

export function PlaceSearch({ onPick, disabled }: { onPick: (p: Place) => void; disabled: boolean }) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Place[]>([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const search = async (text: string) => {
    const query = text.trim();
    if (!query) return;
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(query)}`,
      );
      const data = (await res.json()) as { display_name: string; lat: string; lon: string; boundingbox?: string[] }[];
      const places = data.map((d) => ({
        name: d.display_name,
        lat: Number(d.lat),
        lon: Number(d.lon),
        bbox: d.boundingbox?.length === 4 ? (d.boundingbox.map(Number) as [number, number, number, number]) : undefined,
      }));
      setResults(places);
      if (places.length === 0) setMsg("No places found.");
      else if (places.length === 1 && places[0]) onPick(places[0]);
    } catch {
      setMsg("Search is unavailable right now.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-4">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void search(q);
        }}
        className="flex gap-2"
      >
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search any place… e.g. Kigali"
          aria-label="Search a place"
          disabled={disabled}
          className="min-w-0 flex-1 rounded-md border border-border bg-input px-2.5 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
        />
        <button
          type="submit"
          disabled={disabled || busy || !q.trim()}
          className="rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground disabled:opacity-50"
        >
          {busy ? "…" : "Go"}
        </button>
      </form>
      {msg && <p className="mt-1 text-xs text-muted-foreground">{msg}</p>}
      {results.length > 1 && (
        <ul className="mt-2 space-y-1">
          {results.map((r) => (
            <li key={`${r.lat},${r.lon}`}>
              <button
                type="button"
                onClick={() => {
                  onPick(r);
                  setResults([]);
                }}
                className="w-full truncate rounded px-2 py-1 text-left text-xs text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                {r.name}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
