# VIRTUAL GLOBE Roadmap

## Existing project capabilities (present in source; runtime verification still required)
- [x] NASA GIBS daily satellite imagery as the globe base layer, with OpenStreetMap alternative.
- [x] NASA GIBS science imagery overlays for temperature, precipitation, fire detections and aerosols.
- [x] CesiumJS globe viewer with place search, camera navigation and optional demonstration modes.
- [x] AI Explorer tool-calling workflow for NASA EONET natural events and NASA POWER climate observations.
- [x] AI tools for NASA Earthdata CMR collection discovery and NASA Open Data metadata search.
- [x] AI tool for NASA Image and Video Library search.
- [x] Curated official resource directory for the NASA Space Apps Kigali event, Space Apps, NASA Open Data, Earthdata, NASA Science, NASA APIs, GIBS, CMR, AppEEARS, EONET, POWER and NASA media API.
- [x] Trend Report visualization with observations, linear fit, rate and nominal OLS p-value.
- [x] Trend calculation now supports actual timestamps so missing observations do not compress the time axis.

## Next development and validation
- [ ] Install project dependencies and run the full production build, lint and Vitest suite.
- [ ] Browser-test Cesium initialization, NASA imagery layers, location search and responsive layouts.
- [ ] Verify live NASA EONET, POWER, CMR, NASA Open Data and NASA Image/Video Library calls in deployment.
- [ ] Integrate an analysis-grade MODIS MOD11A2.061 workflow through AppEEARS or LP DAAC; retain QA flags and provenance.
- [ ] Add trend methods that handle seasonality and serial autocorrelation (e.g. appropriate Mann-Kendall/Sen's slope workflow).
- [ ] Improve evidence-based alerts with data coverage, thresholds, uncertainty and clear non-emergency language.
- [ ] Add broader navigation for Earth Data, Analytics, History and Alerts without weakening the globe-first experience.
- [ ] Perform an end-to-end investigation from location and variable selection through measured result, significance assessment and explanation.

## Scientific integrity notes
- NASA GIBS tiles are browse visualizations; use original scientific observations for numeric analysis.
- NASA POWER 2 m air temperature is not MODIS land-surface temperature.
- The current OLS p-value is a nominal screening result and does not correct for seasonality or serial autocorrelation.
- NASA Open Data and CMR search results are discovery metadata, not guaranteed direct measurement downloads.
- NASA Science and the NASA APIs portal are included as official knowledge/reference links; they are not represented as universal queryable measurement APIs.
