# VIRTUAL GLOBE — Update Notes

## Changes in this update

- Added a curated in-app NASA Resource Hub with the NASA Space Apps Kigali event, official Space Apps site, NASA Open Data Portal, NASA Earthdata, NASA Science, NASA APIs portal, GIBS, CMR, AppEEARS, EONET, POWER and NASA Image/Video Library resources.
- Wired the AI Explorer with server-side tools to search NASA Earthdata CMR collection metadata and NASA Open Data catalog metadata.
- Wired the AI Explorer with NASA Image and Video Library search.
- Preserved live NASA EONET natural-event and NASA POWER climate tools, including globe marker/report actions.
- Added AI guidance distinguishing catalogs and reference portals from analysis-grade scientific observations.
- Improved OLS trend calculations to use actual observation timestamps. Missing observations are no longer treated as if they were evenly spaced.
- Updated trend report labels and caveats so nominal OLS p-values are not misrepresented as final climate-trend significance.
- Added tests for the official resource links and timestamp-aware trend regression.

## Important scope and scientific notes

- NASA GIBS layers are browse imagery. Numerical trend analysis must use original data products or supported measurement APIs, not tile colours.
- NASA POWER observations are separate from MODIS land-surface temperature. POWER's 2 m air temperature is not land-surface temperature.
- NASA CMR and NASA Open Data search return dataset discovery metadata; they do not guarantee direct data download links.
- NASA Science and the NASA APIs portal are provided as official reference/knowledge links. The AI does not claim those portals are universal measurement APIs.
- The current OLS p-value is a nominal screening statistic and does not correct for seasonal structure or serial autocorrelation. A more rigorous climate trend method is still a roadmap item.
- The MODIS MOD11A2.061 AppEEARS data extraction workflow is not claimed as complete in this update.

## Verification status

- TypeScript/TSX syntax transpilation check: 77 files parsed, 0 syntax diagnostics.
- Trend-statistics calculation checks: regular trend, irregular timestamp trend, no-trend noise and reference p-value checks passed.
- NASA resource directory checks: all six user-specified NASA/Space Apps portal URLs are present and topic matching finds relevant GIBS/AppEEARS resources.
- Full Vite build, Vitest run and browser preview could not be performed in this environment because dependencies are not installed and the npm registry DNS lookup failed (`EAI_AGAIN` / host resolution failure).
- Live calls to external NASA services and Lovable AI Gateway require network access and, for AI, the project's configured Lovable key/credits.
